<?php
/*
------------------------------------------------------
  www.idiotminds.com
--------------------------------------------------------
*/
session_start();
define('BASE_URL', filter_var('http://labeeto.loc/social/', FILTER_SANITIZE_URL));

//For facebook
define('APP_ID','1464985813757429');
define('APP_SECRET','d713c58abca4a8eb94f4935b5f08ba91');

?>