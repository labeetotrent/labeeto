<?php

class loginbox extends CWidget
{
	public function run()
	{
		$this->render('loginbox');
	}
}