<?php

class homeslider extends CWidget
{
	public function run()
	{
		$this->render('homeslider');
	}
}