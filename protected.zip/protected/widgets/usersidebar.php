<?php

class usersidebar extends CWidget
{
	public function run()
	{
		$this->render('usersidebar');
	}
}